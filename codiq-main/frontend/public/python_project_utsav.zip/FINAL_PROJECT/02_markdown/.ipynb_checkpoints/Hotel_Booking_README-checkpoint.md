Hotel Booking Data Analysis Project

Dataset: hotel_booking.csv

1. Introduction

This project analyzes hotel booking data to understand pricing behavior and booking patterns. The dataset is large and realistic, which makes it suitable for real-world data analytics tasks. The primary objective is to perform exploratory data analysis and apply regression and classification models to hotel pricing data.

2. Dataset Description

The dataset contains detailed information related to hotel bookings, including numerical variables such as Average Daily Rate (ADR) and other booking-related indicators. The data is structured and stored in CSV format.

ADR is a key performance metric in the hospitality industry and is used as the target variable in this project.

3. Data Cleaning and Preparation

Initial inspection is performed to understand column types and missing values. The dataset contains missing values, which is common in real-world hotel data.

Missing numerical values are handled using median imputation to preserve data distribution and reduce the impact of extreme values.

4. Exploratory Data Analysis

Univariate analysis is conducted using histograms to observe the distribution of numeric features. The ADR variable shows skewness, which is expected in pricing data.

Boxplots are used to identify outliers in pricing and booking-related features. These values are analyzed rather than removed, as they may represent premium bookings.

Correlation analysis is performed to understand relationships between numeric variables. This helps in identifying which features influence pricing.

5. Regression Modeling

ADR is selected as the dependent variable. All other numeric variables are used as independent variables.

The dataset is split into training and testing sets using an 80–20 split. A Linear Regression model is trained using scikit-learn.

Model performance is evaluated using Mean Squared Error, Mean Absolute Error, and R² score.

6. Classification Modeling

ADR is converted into a binary variable representing high-price and low-price bookings. This conversion allows classification analysis.

A Logistic Regression model is trained to classify bookings. Accuracy score and confusion matrix are used for evaluation.

7. Conclusion

The project successfully applies data analytics techniques to hotel booking data. Both regression and classification models are implemented, demonstrating practical application of machine learning concepts.

8. Viva Perspective

Key points to explain in viva:

ADR is a standard hospitality performance metric.

Median imputation is suitable for skewed pricing data.

Regression explains pricing relationships.

Classification helps categorize booking types.