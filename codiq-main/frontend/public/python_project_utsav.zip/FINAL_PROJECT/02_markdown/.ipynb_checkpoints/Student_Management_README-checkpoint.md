Student Management Data Analysis Project

Datasets:

International students Time management data.csv

Sheet2.csv

1. Introduction

This project analyzes international student time management data. The objective is to understand how students allocate time and how different factors relate to performance. An additional dataset (Sheet2) is merged to enrich the analysis.

2. Dataset Description

The primary dataset contains time management and performance-related attributes of students. Sheet2 contains supplementary information that complements the main dataset.

Both datasets are merged column-wise to create a single comprehensive dataset for analysis.

3. Data Preparation

The datasets are loaded separately and merged using Pandas. Data inspection is performed to ensure correct alignment of columns.

Missing numerical values are handled using median imputation to avoid loss of data.

4. Exploratory Data Analysis

Histograms are used to analyze the distribution of time allocation variables. This helps understand how students distribute their time.

Correlation analysis is performed to identify relationships between time management variables and performance-related attributes.

5. Regression Analysis

A numerical performance-related column is selected as the target variable. Remaining numerical columns are used as predictors.

The dataset is split into training and testing sets. A Linear Regression model is trained and evaluated using standard regression metrics.

6. Classification Analysis

The performance variable is converted into a binary category representing high-performing and low-performing students.

A Logistic Regression model is trained to classify students based on performance.

7. Conclusion

This project demonstrates how data analytics can be applied to educational data. Merging datasets improves analysis quality, and machine learning models help identify performance patterns.

8. Viva Perspective

In viva, explain:

Why Sheet2 was merged to improve context.

Why regression was used for numeric performance prediction.

Why classification helps categorize students.

How train-test split prevents overfitting.