Dataset: onlinefoods.csv

1. Introduction

This project focuses on analyzing an online food ordering dataset using Python. The goal of the project is to understand customer-related numerical patterns, explore relationships between variables, and apply supervised learning techniques to make predictions. The project follows the standard Data Analytics workflow, starting from data understanding and ending with model evaluation.

The dataset represents real-world food ordering behavior, making it suitable for exploratory data analysis and basic machine learning models.

2. Dataset Description

The dataset is stored in CSV format and contains structured data related to online food orders. It includes numerical attributes such as customer age, ratings, and other measurable features. These numeric attributes allow statistical analysis, visualization, and predictive modeling.

Categorical columns are inspected for understanding but are not directly used in regression models to avoid encoding complexity, as per the project scope.

3. Tools and Libraries Used

The project is implemented using Python and the following libraries:

Pandas is used for loading and manipulating structured data.

NumPy is used for numerical operations.

Matplotlib and Seaborn are used for data visualization.

Scikit-learn is used for regression and classification models.

These libraries are industry-standard and commonly used in academic data analytics projects.

4. Data Understanding and Cleaning

The dataset is loaded using the Pandas library. Initial inspection is done using functions such as head(), info(), and describe() to understand the structure, data types, and statistical properties of the dataset.

Missing values are identified using null value checks. Since the dataset contains numerical values, missing data is handled using median imputation. Median is preferred over mean because it is less affected by extreme values, which are common in customer-related datasets.

5. Exploratory Data Analysis (EDA)

Exploratory Data Analysis is performed to understand the behavior of data before applying machine learning models.

Univariate analysis is carried out using histograms to observe the distribution of individual numerical variables. This helps identify skewness and the overall spread of data.

Boxplots are used to detect outliers. Outliers are not removed blindly because, in food ordering data, extreme values may represent genuine customer behavior rather than errors.

Correlation analysis is performed using a correlation matrix and heatmap. This helps identify relationships between numerical variables and understand which features may influence the target variable.

6. Regression Analysis

A numerical column is selected as the target variable, while the remaining numerical columns are treated as independent variables.

The dataset is split into training and testing sets using an 80–20 ratio. This ensures that model performance is evaluated on unseen data.

A Linear Regression model is trained using scikit-learn. The model learns relationships between independent variables and the target variable.

Model performance is evaluated using Mean Squared Error, Mean Absolute Error, and R² score. These metrics help measure prediction accuracy and goodness of fit.

7. Classification Analysis

To demonstrate classification, the regression target is converted into a binary variable using the median as a threshold. Values above the median are labeled as high, and values below the median are labeled as low.

A Logistic Regression model is trained on this binary target. Model performance is evaluated using accuracy score and confusion matrix.

8. Conclusion

This project demonstrates a complete data analytics workflow, including data cleaning, EDA, regression, and classification. The analysis provides meaningful insights into customer behavior and successfully applies supervised learning models using scikit-learn.

9. Viva Perspective (What to Say)

If asked in the viva:

EDA was performed to understand data patterns before modeling.

Median imputation was used to handle missing values due to skewed data.

Linear regression was chosen for numeric prediction.

Logistic regression was used to convert the problem into classification.

Train-test split was used to avoid overfitting.